<?php
session_start();

$mysqli = require __DIR__ . "/dbcon.php";

$u_email = $_SESSION['email'];
$p_head = $_POST['p_head'];
$p_body = $_POST['p_body'];

$sql = "insert into posts (u_email, p_head, p_body) values ('$u_email', '$p_head', '$p_body')";

if($mysqli->query($sql)===true) {
	header("location: ../posts.php");
}else {
	echo "Error: " . $sql . "<br>" . $mysqli->error;
}

$mysqli->close;
?>