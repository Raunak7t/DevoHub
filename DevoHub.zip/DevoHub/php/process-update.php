<?php
session_start();

$mysqli = require __DIR__ . "/dbcon.php";

$sessionemail = $_SESSION['email'];

$username = $_POST['username'];
$email = $_POST['email'];
$portfolio = $_POST['portfolio'];
$password = $_POST['password'];		

$sql = "UPDATE users SET username = '$username', email = '$email', portfolio = '$portfolio', password = '$password' WHERE email = '$sessionemail'";
		
if ($mysqli->query($sql) === TRUE) {
	header("Location: ../userprofile.php?email=" . urlencode($email));
} else {
	$updateError = "Error: " . $sql . "<br>" . $mysqli->error;
	echo $updateError;
}
		
$mysqli->close();
?>