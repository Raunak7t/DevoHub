<?php

$host = "0.0.0.0:3306";
$username = "root";
$password = "root";
$dbname = "devohub";

$mysqli = new mysqli($host, $username, $password, $dbname);
                     
if ($mysqli->connect_errno) {
	die("Connection error: " . $mysqli->connect_error);
}

return $mysqli;