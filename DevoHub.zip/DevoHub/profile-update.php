<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
// Redirect to the login page if not logged in
    header("Location: index.html");
    exit;
}

$mysqli = require __DIR__ . "/php/dbcon.php";

$email = $_SESSION['email'];

$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $mysqli->query($sql);

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    $username = $row['username'];
    $email = $row['email'];
    $portfolio = $row['portfolio'];
    $password = $row['password'];
}

$mysqli->close();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>DevoHub | Profile Update</title>
	<link rel="stylesheet" href="css/resets.css">
	<link rel="stylesheet" href="css/nav.css">
	<link rel="stylesheet" href="css/footer.css">
	<link rel="stylesheet" href="css/signuplogin.css">
	<link rel="stylesheet" href="css/responsive.css">
</head>
<body>
	<div class="bg-img">
	</div>
	<?php
		include 'nav.html';
	?>
	<div class="sl-box cool-container">
		<header class="sl-header">
			<h1>Update Profile</h1>
			<p>Keep your details up to date!</p>
		</header>
		<main class="sl-body">
			<form action="php/process-update.php" method="post">
				<p>
					<label for="username">Update name: </label>
					<input type="text" id="username" class="input-data" name="username" required value="<?php echo $username?>">
				</p>
				<p>
					<label for="email">Update e-mail: </label>
					<input type="email" id="email" name="email" class="input-data" required value="<?php echo $email?>">
				</p>
				<p>
					<label for="portfolio">Update portfolio link: </label>
					<input type="url" id="portfolio" name="portfolio" class="input-data" value="<?php echo $portfolio?>">
				</p>
				
				<p>
					<label for="password">Update password: </label>
					<input type="password" id="password" name="password" class="input-data" required value="<?php echo $password?>">
				</p>
				<p>
					<input type="submit" id="submit" class="btn hover-link" value="Update">
				</p>
			</form>
		</main>
	</div>
	<?php
		include 'footer.html';
	?>
</body>
</html>