<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
// Redirect to the login page if not logged in
    header("Location: index.html");
    exit;
}

$mysqli = require __DIR__ . "/php/dbcon.php";

// Retrieve all user fields from the database
$sql = "SELECT * FROM users ORDER BY ratings desc";
$result = $mysqli->query($sql);

$mysqli->close();
?>

<!DOCTYPE html>
<html>
<head>
	<title>DevoHub | Profiles</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" href="css/resets.css">
	<link rel="stylesheet" href="css/nav.css">
	<link rel="stylesheet" href="css/profiles.css">
	<link rel="stylesheet" href="css/footer.css">
	<link rel="stylesheet" href="css/responsive.css">
	<script src="https://kit.fontawesome.com/4718b98a04.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="bg-img">
	</div>
	
	<?php
		include 'nav.html';
	?>
	
	<main>
		<div class="container">
			<h2 class="flash header-text">Top profiles</h2>
		</div>
		<div class="container flex profiles">
		<?php
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
			
				$id = $row['id'];
				$username = $row['username'];
				$email = $row['email'];
				$ratings = $row['ratings'];
				
				$userprofileURL = "userprofile.php?email=" . urlencode($email);
			
				echo "
				<a href='$userprofileURL' class='user flex cool-container' id='$id'>
					<div class='username'>
						<h3><i class='fa fa-user-circle-o icon'></i>&nbsp;&nbsp;$username</h3>
					</div>
					<div class='ratings flex'>
						<i class='fa fa-star icon'></i>
						<p>$ratings</p>
					</div>
				</a>";
			}
		}
		?>
		</div>
	</main>
	
	<?php
		include 'footer.html';
	?>
</body>
</html>