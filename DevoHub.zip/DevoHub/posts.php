<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
// Redirect to the login page if not logged in
    header("Location: index.html");
    exit;
}

$mysqli = require __DIR__ . "/php/dbcon.php";

if (isset($_GET['action'])) {

$p_id = $_GET['p_id'];

// Check if the like link is clicked
	if ($_GET['action'] == 'like'){
		// Update the likes in the database
		$updateSql = "UPDATE posts SET likes = likes + 1 WHERE p_id = '$p_id'";
		$mysqli->query($updateSql);
		
		// Check if the update was successful
		if ($mysqli->affected_rows > 0) {
			//updated successfully
			header("Location: posts.php#$p_id");
			exit;
		} else {
			echo "Error updating ratings: " . $mysqli->error;
		}
	}
	
// Check if the dislike link is clicked
	if ($_GET['action'] == 'dislike'){
		// Update the dislikes in the database*/
		$updateSql = "UPDATE posts SET dislikes = dislikes + 1 WHERE p_id = '$p_id'";
		$mysqli->query($updateSql);
		
		// Check if the update was successful
		if ($mysqli->affected_rows > 0) {
			//updated successfully
			header("Location: posts.php#$p_id");
			exit;
		} else {
			echo "Error updating dislikes: " . $mysqli->error;
		}
	}

// Check if the delete link is clicked
	if ($_GET['action'] == 'delete'){
		// Update the likes in the database
		$updateSql = "DELETE FROM posts WHERE p_id = '$p_id'";
		$mysqli->query($updateSql);
		
		// Check if the update was successful
		if ($mysqli->affected_rows > 0) {
			//updated successfully
			header("Location: posts.php#$p_id");
			exit;
		} else {
			echo "Error updating ratings: " . $mysqli->error;
		}
	}
}


// Retrieve all user fields from the database
$sort = isset($_GET['sort']) ? $_GET['sort'] : '';

//$u_email = $_SESSION['email'];
$sql = "SELECT p.p_id, p.p_head, p.p_body, p.likes, p.dislikes, u.username, u.email
FROM posts p
JOIN users u ON p.u_email = u.email
ORDER BY ";

if ($sort === 'recent') {
    $sql .= "p.p_id DESC";
} else {
    $sql .= "p.likes DESC"; // Default sorting by likes
}

$result = $mysqli->query($sql);

$mysqli->close();
?>

<!DOCTYPE html>
<html>
<head>
	<title>DevoHub | Posts</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" href="css/resets.css">
	<link rel="stylesheet" href="css/nav.css">
	<link rel="stylesheet" href="css/posts.css">
	<link rel="stylesheet" href="css/footer.css">
	<link rel="stylesheet" href="css/responsive.css">
	<script src="https://kit.fontawesome.com/4718b98a04.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="bg-img">
	</div>
	
	<?php
		include 'nav.html';
	?>
	
	<main>
		
		<div class="container cool-container">
			<div class="flex post-nav">
			<a class="hover-link" onclick="displayPostCon()"><h3><i class="fa-solid fa-plus"></i>&nbsp;&nbsp;Create Post</h3></a>
			<a href="posts.php" class="hover-link"><h3><i class="fa-solid fa-fire"></i>&nbsp;&nbsp;Trending Posts</h3></a>
			<a href="?sort=recent" class="hover-link"><h3><i class="fa-solid fa-newspaper"></i>&nbsp;&nbsp;Recent Posts</h3></a>
			</div>
		</div>
		
		<div  id="create-post-container" style="display: none">
		<div class="container flex create-post">
			<h2 class="flash header-text">Create post&nbsp;<i class="fa-solid fa-right-long icon"></i></h2>
			<div class="cool-container post-form">
				<form action="php/create-post.php" method="post">
					<p>
						<label for="p_head">Title: </label>
						<input type="text" id="p_head" name="p_head" class="input-data" required>
					</p>
					<br>
					<p>
						<label for="p_body">Content: </label>
						<textarea id="p_body" name="p_body" class="input-data" rows="2"></textarea>
					</p>
					
					<p>
						<input type="submit" id="submit" class="btn hover-link" value="Create Post">
					</p>
				</form>
			</div>
		</div>
		</div>
		
		<div class="container header-text-sec">
			<?php
			if ($sort === 'recent') {
				echo "<h2 class='flash header-text'><i class='fa-solid fa-newspaper'></i>&nbsp;&nbsp;Recent posts</h2>";
			} else {
				echo "<h2 class='flash header-text'><i class='fa-solid fa-fire'></i>&nbsp;&nbsp;Trending posts</h2>";
			}
			?>
		</div>
		
		<div class="container flex posts">
		<?php
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
			
				$username = $row['username'];
				$email = $row['email'];
				$p_id = $row['p_id'];
				$p_head = $row['p_head'];
				$p_body = $row['p_body'];
				$likes = $row['likes'];
				$dislikes = $row['dislikes'];
				
				$userprofileURL = "userprofile.php?email=" . urlencode($email);
				
				echo "
				<div class='post'>
				<div class='cool-container' id='$p_id'>
					<div class='post-head'>
						<h2>$p_head</h2>
					</div>
					
					<div class='post-body'>
						<p>$p_body</p>
					</div>
					
					<div class='post-bottom flex'>
						<a href='$userprofileURL' class='username'>
							<h3><i class='fa fa-user-circle-o icon'></i>&nbsp;&nbsp;$username</h3>
						</a>
						<div class='likes-dislikes flex'>
							<a href='posts.php?p_id=$p_id&action=like' class='likes flex'>
								<i class='fa fa-thumbs-up icon'></i>
								<p>$likes</p>
							</a>
							<a href='posts.php?p_id=$p_id&action=dislike' class='dislikes flex'>
								<i class='fa fa-thumbs-down icon'></i>
								<p>$dislikes</p>
							</a>
						</div>
					</div>
				</div>";
					
					
				if($_SESSION['role'] == 'admin')
				{
					echo "
						<a href='posts.php?p_id=$p_id&action=delete' class='delete-post hover-link btn'><i class='fa-solid fa-trash-can'></i>&nbsp;Delete</a>";
				}
					
				echo "</div>";
			}
		}
		?>

		</div>
		
	</main>
	
	<?php
		include 'footer.html';
	?>
	
	<script>
	function displayPostCon() {
		var createPostContainer = document.getElementById('create-post-container');
		createPostContainer.style.display = createPostContainer.style.display === 'none' ? 'block' : 'none';
	}
	</script>
</body>
</html>