<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email']) || $_SESSION['role']=='user') {
// Redirect to the login page if not logged in
    header("Location: index.html");
    exit;
}

$mysqli = require __DIR__ . "/php/dbcon.php";

if (isset($_GET['action'])) {
$email = $_GET['email'];
// Check if the delete link is clicked
	if ($_GET['action'] == 'delete'){
		// Update the likes in the database
		$updateSql = "DELETE FROM users WHERE email = '$email'";
		$mysqli->query($updateSql);
		
		// Check if the update was successful
		if ($mysqli->affected_rows > 0) {
			//updated successfully
			header("Location: adminpanel.php");
			exit;
		} else {
			echo "Error updating ratings: " . $mysqli->error;
		}
	}
}


// Retrieve all user fields from the database
$sql = "SELECT * FROM users";
$result = $mysqli->query($sql);

$total_users = $result->num_rows;

$mysqli->close();
?>

<!DOCTYPE html>
<html>
<head>
	<title>DevoHub | Admin Panel</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" href="css/resets.css">
	<link rel="stylesheet" href="css/nav.css">
	<link rel="stylesheet" href="css/adminpanel.css">
	<link rel="stylesheet" href="css/footer.css">
	<link rel="stylesheet" href="css/responsive.css">
	<script src="https://kit.fontawesome.com/4718b98a04.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="bg-img">
	</div>
	
	<?php
		include 'nav.html';
	?>
	
	<main>
	
		<div class="container cool-container">
			<div class="flex admin-nav">
				<a class="hover-link"><h3>Total users :&nbsp;<?php echo $total_users; ?></h3></a>
				<a href="posts.php" class="hover-link"><h3><i class="fa-solid fa-fire"></i>&nbsp;&nbsp;Manage Posts</h3></a>
				<a href="posts.php?sort=recent" class="hover-link"><h3><i class="fa-solid fa-newspaper"></i>&nbsp;&nbsp;Feedbacks</h3></a>
			</div>
		</div>
		
		<div class="container">
			<h2 class='flash header-text'><i class='fa fa-user-circle-o'></i>&nbsp;&nbsp;Manage Users</h2>
		</div>
		
		<div class="container">
		<?php
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
			
				$id = $row['id'];
				$username = $row['username'];
				$email = $row['email'];
				$portfolio = $row['portfolio'];
				$ratings = $row['ratings'];
				
				$userprofileURL = "userprofile.php?email=" . urlencode($email);
			
		
				echo "
				<div class='cool-container flex user-data'>
					<div class='left-ud'>
						<p>E-mail: $email</p>
						<p>Portfolio: $portfolio</p>
						<p>Ratings: $ratings</p>
					</div>
					<div class='right-ud flex'>
						<a href='$userprofileURL'><h3>$id&nbsp;&nbsp;<i class='fa fa-user-circle-o'></i>&nbsp;&nbsp;$username</h3></a>
						<a href='adminpanel.php?email=$email&action=delete' class='delete-user hover-link btn'><i class='fa-solid fa-trash-can'></i>&nbsp;Delete User</a>
					</div>
				</div>
				<br>";
			}
		}
		?>
		</div>
	</main>
	
	<?php
		include 'footer.html';
	?>
	</body>
	</html>