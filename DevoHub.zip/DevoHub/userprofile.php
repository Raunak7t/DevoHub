<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
// Redirect to the login page if not logged in
    header("Location: index.html");
    exit;
}

$mysqli = require __DIR__ . "/php/dbcon.php";

$email = $_GET['email'];
$sessionemail = $_SESSION['email'];

// Check if the rating link is clicked
if (isset($_GET['action']) && $_GET['action'] == 'rate') {

    // Update the ratings in the database*/
    $updateSql = "UPDATE users SET ratings = ratings + 1 WHERE email = '$email'";
    $mysqli->query($updateSql);

    // Check if the update was successful
    if ($mysqli->affected_rows > 0) {
        // Ratings updated successfully
        header("Location: userprofile.php?email=$email");
        exit;
    } else {
        echo "Error updating ratings: " . $mysqli->error;
    }
}

// Retrieve all user fields from the database
$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $mysqli->query($sql);

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    $id = $row['id'];
    $username = $row['username'];
    $email = $row['email'];
    $portfolio = $row['portfolio'];
    $ratings = $row['ratings'];
}

$mysqli->close();
?>

<!DOCTYPE html>
<html>
<head>
	<title>DevoHub | User</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" href="css/resets.css">
	<link rel="stylesheet" href="css/nav.css">
	<link rel="stylesheet" href="css/footer.css">
	<link rel="stylesheet" href="css/userprofile.css">
	<link rel="stylesheet" href="css/responsive.css">
	<script src="https://kit.fontawesome.com/4718b98a04.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="bg-img">
	</div>
	<?php
		include 'nav.html';
	?>
	
	<main class="container psec">
	
		<?php
		
		if ($sessionemail == $email) {
			echo "
			<div class='cool-container edit-bar'>
				<a href='profile-update.php' class='hover-link'><h3>Update profile&nbsp;&nbsp;<i class='fa fa-pencil-square-o icon'></i></h3></a>
			</div>";
		}
		
		echo "
		<iframe class='cool-container' src='$portfolio'></iframe>
		
		<div class='cool-container interact-bar flex'>
			<div class='username flex'>
				<a href='profiles.php#$id'><i class='fa fa-solid fa-left-long icon'></i></a>
				<h3><i class='fa fa-user-circle icon'></i>&nbsp;&nbsp;$username</h3>
			</div>
			<div class='cnr flex'>
				<a href='mailto:$email' >
					<i class='fa fa-comments-o icon'></i>
				</a>
				<a href='posts.php'>
					<i class='fa fa-connectdevelop icon'></i>
				</a>
				<a href='userprofile.php?email=$email&action=rate'>
					<i class='fa fa-star icon'></i>
					$ratings
				</a>
			</div>
		</div>
		";
	?>
	</main>
	
	<?php
		include 'footer.html';
	?>
	
</body>
</html>